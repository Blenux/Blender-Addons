# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "QSM",
    "author" : "Juso3D", 
    "description" : "Add Multiple Subdivision Modifers to All Selected Meshes",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 1),
    "location" : "N-Panel (Default N Keymap), Popup Panel (Default ALT+Q Keymap)",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


def find_user_keyconfig(key):
    km, kmi = addon_keymaps[key]
    for item in bpy.context.window_manager.keyconfigs.user.keymaps[km.name].keymap_items:
        found_item = False
        if kmi.idname == item.idname:
            found_item = True
            for name in dir(kmi.properties):
                if not name in ["bl_rna", "rna_type"] and not name[0] == "_":
                    if not kmi.properties[name] == item.properties[name]:
                        found_item = False
        if found_item:
            return item
    print(f"Couldn't find keymap item for {key}, using addon keymap instead. This won't be saved across sessions!")
    return kmi


def sna_update_sna_isoline_display_C6A05(self, context):
    sna_updated_prop = self.sna_isoline_display
    for i_27B97 in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_27B97].modifiers['Subdivision'].show_only_control_edges = sna_updated_prop


def sna_update_sna_master_level_6DB14(self, context):
    sna_updated_prop = self.sna_master_level
    for i_25D73 in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_25D73].modifiers['Subdivision'].levels = sna_updated_prop


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_keymap_functions_EB7BE(layout_function, ):
    box_7E952 = layout_function.box()
    box_7E952.alert = False
    box_7E952.enabled = True
    box_7E952.active = True
    box_7E952.use_property_split = False
    box_7E952.use_property_decorate = False
    box_7E952.alignment = 'Expand'.upper()
    box_7E952.scale_x = 1.0
    box_7E952.scale_y = 1.0
    box_7E952.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_4E3F8 = box_7E952.row(heading='', align=False)
    row_4E3F8.alert = False
    row_4E3F8.enabled = True
    row_4E3F8.active = True
    row_4E3F8.use_property_split = False
    row_4E3F8.use_property_decorate = False
    row_4E3F8.scale_x = 1.0
    row_4E3F8.scale_y = 1.0
    row_4E3F8.alignment = 'Center'.upper()
    row_4E3F8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_4E3F8.label(text='Default Keymaps', icon_value=0)
    box_7E952.prop(find_user_keyconfig('2E0B0'), 'type', text='Popup Panel', full_event=True)
    box_7E952.separator(factor=1.0)
    box_7E952.prop(find_user_keyconfig('62B11'), 'type', text='Select ALL', full_event=True)
    box_7E952.prop(find_user_keyconfig('EA2B7'), 'type', text='Add', full_event=True)
    box_7E952.prop(find_user_keyconfig('69F63'), 'type', text='Remove', full_event=True)


class SNA_AddonPreferences_BF64D(bpy.types.AddonPreferences):
    bl_idname = 'qsm'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout.prop(bpy.context.scene, 'sna_show_info', text='Show info', icon_value=0, emboss=True, toggle=True)
            if bpy.context.scene.sna_show_info:
                row_9E48E = layout.row(heading='', align=True)
                row_9E48E.alert = False
                row_9E48E.enabled = True
                row_9E48E.active = True
                row_9E48E.use_property_split = False
                row_9E48E.use_property_decorate = False
                row_9E48E.scale_x = 1.0
                row_9E48E.scale_y = 1.0
                row_9E48E.alignment = 'Center'.upper()
                row_9E48E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_9E48E.label(text='Some issues, if they get in the way, let me know!', icon_value=1)
            layout_function = layout
            sna_keymap_functions_EB7BE(layout_function, )


class SNA_OT_Remove_D06A0(bpy.types.Operator):
    bl_idname = "sna.remove_d06a0"
    bl_label = "Remove"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object.modifiers:
            bpy.ops.object.modifier_remove('INVOKE_DEFAULT', modifier='Subdivision')
        bpy.ops.object.shade_flat('INVOKE_DEFAULT', )
        bpy.ops.object.make_links_data('INVOKE_DEFAULT', type='MODIFIERS')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_22836(bpy.types.Operator):
    bl_idname = "sna.add_22836"
    bl_label = "Add"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object.modifiers:
            pass
        else:
            bpy.ops.object.modifier_add('INVOKE_DEFAULT', type='SUBSURF')
        bpy.ops.object.shade_smooth('INVOKE_DEFAULT', )
        bpy.ops.object.make_links_data('INVOKE_DEFAULT', type='MODIFIERS')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Select_All_Mesh_2117B(bpy.types.Operator):
    bl_idname = "sna.select_all_mesh_2117b"
    bl_label = "Select ALL MESH"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        prev_context = bpy.context.area.type
        bpy.context.area.type = 'VIEW_3D'
        bpy.ops.object.select_by_type('INVOKE_DEFAULT', extend=True, type='MESH')
        bpy.context.area.type = prev_context
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_More_00F1C(bpy.types.Operator):
    bl_idname = "sna.more_00f1c"
    bl_label = "More"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_master_level = int(bpy.context.scene.sna_master_level + 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Less_03742(bpy.types.Operator):
    bl_idname = "sna.less_03742"
    bl_label = "Less"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        bpy.context.scene.sna_master_level = int(bpy.context.scene.sna_master_level - 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_test_BF453(layout_function, ):
    if bpy.context.scene.sna_show_options:
        for i_1A57C in range(len(bpy.context.view_layer.objects.selected)):
            layout_function.prop(bpy.context.view_layer.objects.selected[i_1A57C], 'name', text='', icon_value=0, emboss=True)


class SNA_PT_QUICK_SUBDIVISON_MODIFIER_D341B(bpy.types.Panel):
    bl_label = 'Quick Subdivison Modifier'
    bl_idname = 'SNA_PT_QUICK_SUBDIVISON_MODIFIER_D341B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'QSM'
    bl_order = 0
    bl_ui_units_x=25

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        grid_C9726 = layout.grid_flow(columns=3, row_major=True, even_columns=True, even_rows=True, align=False)
        grid_C9726.enabled = True
        grid_C9726.active = True
        grid_C9726.use_property_split = False
        grid_C9726.use_property_decorate = False
        grid_C9726.alignment = 'Expand'.upper()
        grid_C9726.scale_x = 1.0
        grid_C9726.scale_y = 1.0
        grid_C9726.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = grid_C9726.operator('object.select_by_type', text='Select (ALL) Meshes', icon_value=130, emboss=True, depress=False)
        op.extend = True
        op.type = 'MESH'
        op = grid_C9726.operator('sna.add_22836', text='Add', icon_value=31, emboss=True, depress=False)
        op = grid_C9726.operator('sna.remove_d06a0', text='Remove', icon_value=32, emboss=True, depress=False)
        if bpy.context.view_layer.objects.active:
            box_BC168 = layout.box()
            box_BC168.alert = False
            box_BC168.enabled = True
            box_BC168.active = True
            box_BC168.use_property_split = False
            box_BC168.use_property_decorate = False
            box_BC168.alignment = 'Expand'.upper()
            box_BC168.scale_x = 1.0
            box_BC168.scale_y = 1.0
            box_BC168.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if bpy.context.active_object.modifiers:
                split_ADD5A = box_BC168.split(factor=0.699999988079071, align=False)
                split_ADD5A.alert = False
                split_ADD5A.enabled = True
                split_ADD5A.active = True
                split_ADD5A.use_property_split = False
                split_ADD5A.use_property_decorate = False
                split_ADD5A.scale_x = 1.0
                split_ADD5A.scale_y = 1.4499995708465576
                split_ADD5A.alignment = 'Expand'.upper()
                split_ADD5A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                split_ADD5A.prop(bpy.context.scene, 'sna_master_level', text='Interations', icon_value=0, emboss=True, slider=True)
                op = split_ADD5A.operator('sna.more_00f1c', text='', icon_value=7, emboss=True, depress=False)
                op = split_ADD5A.operator('sna.less_03742', text='', icon_value=5, emboss=True, depress=False)
            if bpy.context.view_layer.objects.active.type == 'MESH':
                grid_B98E0 = box_BC168.grid_flow(columns=3, row_major=True, even_columns=True, even_rows=True, align=False)
                grid_B98E0.enabled = True
                grid_B98E0.active = True
                grid_B98E0.use_property_split = False
                grid_B98E0.use_property_decorate = False
                grid_B98E0.alignment = 'Expand'.upper()
                grid_B98E0.scale_x = 1.0
                grid_B98E0.scale_y = 1.0
                grid_B98E0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                grid_B98E0.prop(bpy.context.area.spaces[0].overlay, 'show_wireframes', text='Global Wireframe', icon_value=625, emboss=True, toggle=True)
                if bpy.context.active_object.modifiers:
                    grid_B98E0.prop(bpy.context.scene, 'sna_isoline_display', text='Isoline Display', icon_value=482, emboss=True, toggle=True)
                    grid_B98E0.prop(bpy.context.scene, 'sna_show_options', text='Show Options', icon_value=23, emboss=True, toggle=True)
        if bpy.context.view_layer.objects.selected:
            if bpy.context.active_object.modifiers:
                if (property_exists("bpy.context.active_object.modifiers", globals(), locals()) and 'Subdivision' in bpy.context.active_object.modifiers):
                    if bpy.context.scene.sna_show_options:
                        box_C0461 = layout.box()
                        box_C0461.alert = False
                        box_C0461.enabled = True
                        box_C0461.active = True
                        box_C0461.use_property_split = False
                        box_C0461.use_property_decorate = False
                        box_C0461.alignment = 'Expand'.upper()
                        box_C0461.scale_x = 1.0
                        box_C0461.scale_y = 1.0
                        box_C0461.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                        grid_461B5 = box_C0461.grid_flow(columns=8, row_major=False, even_columns=True, even_rows=True, align=True)
                        grid_461B5.enabled = True
                        grid_461B5.active = True
                        grid_461B5.use_property_split = False
                        grid_461B5.use_property_decorate = False
                        grid_461B5.alignment = 'Expand'.upper()
                        grid_461B5.scale_x = 1.0
                        grid_461B5.scale_y = 1.149999976158142
                        grid_461B5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                        layout_function = grid_461B5
                        sna_test_BF453(layout_function, )
                        if bpy.context.scene.sna_show_options:
                            for i_0736A in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_0736A].modifiers['Subdivision'], 'levels', text='', icon_value=0, emboss=True, slider=True)
                        if bpy.context.scene.sna_show_options:
                            for i_F4724 in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_F4724].modifiers['Subdivision'], 'show_on_cage', text='', icon_value=0, emboss=True)
                        if bpy.context.scene.sna_show_options:
                            for i_E239F in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_E239F].modifiers['Subdivision'], 'show_in_editmode', text='', icon_value=0, emboss=True, toggle=True)
                        if bpy.context.scene.sna_show_options:
                            for i_3064B in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_3064B].modifiers['Subdivision'], 'show_viewport', text='', icon_value=0, emboss=True)
                        if bpy.context.scene.sna_show_options:
                            for i_782C1 in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_782C1].modifiers['Subdivision'], 'show_render', text='', icon_value=0, emboss=True)
                        if bpy.context.scene.sna_show_options:
                            for i_2B513 in range(len(bpy.context.view_layer.objects.selected)):
                                grid_461B5.prop(bpy.context.view_layer.objects.selected[i_2B513].modifiers['Subdivision'], 'show_only_control_edges', text='Isoline', icon_value=0, emboss=True, toggle=True)
            else:
                if bpy.context.view_layer.objects.active.type == 'MESH':
                    box_7A338 = layout.box()
                    box_7A338.alert = False
                    box_7A338.enabled = True
                    box_7A338.active = True
                    box_7A338.use_property_split = False
                    box_7A338.use_property_decorate = False
                    box_7A338.alignment = 'Expand'.upper()
                    box_7A338.scale_x = 1.0
                    box_7A338.scale_y = 1.0
                    box_7A338.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_E981C = box_7A338.row(heading='', align=True)
                    row_E981C.alert = True
                    row_E981C.enabled = True
                    row_E981C.active = True
                    row_E981C.use_property_split = False
                    row_E981C.use_property_decorate = False
                    row_E981C.scale_x = 1.0
                    row_E981C.scale_y = 1.0
                    row_E981C.alignment = 'Center'.upper()
                    row_E981C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_E981C.label(text='Selected Object has no Subdivision Modifier (Press ADD)', icon_value=2)
                else:
                    box_3AE18 = layout.box()
                    box_3AE18.alert = False
                    box_3AE18.enabled = True
                    box_3AE18.active = True
                    box_3AE18.use_property_split = False
                    box_3AE18.use_property_decorate = False
                    box_3AE18.alignment = 'Expand'.upper()
                    box_3AE18.scale_x = 1.0
                    box_3AE18.scale_y = 1.0
                    box_3AE18.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_268C8 = box_3AE18.row(heading='', align=True)
                    row_268C8.alert = True
                    row_268C8.enabled = True
                    row_268C8.active = True
                    row_268C8.use_property_split = False
                    row_268C8.use_property_decorate = False
                    row_268C8.scale_x = 1.0
                    row_268C8.scale_y = 1.0
                    row_268C8.alignment = 'Center'.upper()
                    row_268C8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                    row_268C8.label(text='Selected is not a Mesh Type!', icon_value=2)
        else:
            box_45976 = layout.box()
            box_45976.alert = False
            box_45976.enabled = True
            box_45976.active = True
            box_45976.use_property_split = False
            box_45976.use_property_decorate = False
            box_45976.alignment = 'Expand'.upper()
            box_45976.scale_x = 1.0
            box_45976.scale_y = 1.0
            box_45976.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3E7FD = box_45976.row(heading='', align=True)
            row_3E7FD.alert = True
            row_3E7FD.enabled = True
            row_3E7FD.active = True
            row_3E7FD.use_property_split = False
            row_3E7FD.use_property_decorate = False
            row_3E7FD.scale_x = 1.0
            row_3E7FD.scale_y = 1.0
            row_3E7FD.alignment = 'Center'.upper()
            row_3E7FD.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_3E7FD.label(text='No Selected Objects', icon_value=2)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_show_options = bpy.props.BoolProperty(name='Show Options', description='', default=False)
    bpy.types.Scene.sna_show_info = bpy.props.BoolProperty(name='Show Info', description='', default=False)
    bpy.types.Scene.sna_master_level = bpy.props.IntProperty(name='Master Level', description='', default=1, subtype='NONE', min=0, soft_min=0, max=6, update=sna_update_sna_master_level_6DB14)
    bpy.types.Scene.sna_single_levels = bpy.props.IntProperty(name='Single Levels', description='', default=1, subtype='NONE')
    bpy.types.Scene.sna_isoline_display = bpy.props.BoolProperty(name='Isoline Display', description='', default=True, update=sna_update_sna_isoline_display_C6A05)
    bpy.utils.register_class(SNA_AddonPreferences_BF64D)
    bpy.utils.register_class(SNA_OT_Remove_D06A0)
    bpy.utils.register_class(SNA_OT_Add_22836)
    bpy.utils.register_class(SNA_OT_Select_All_Mesh_2117B)
    bpy.utils.register_class(SNA_OT_More_00F1C)
    bpy.utils.register_class(SNA_OT_Less_03742)
    bpy.utils.register_class(SNA_PT_QUICK_SUBDIVISON_MODIFIER_D341B)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_panel', 'Q', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=True)
    kmi.properties.name = 'SNA_PT_QUICK_SUBDIVISON_MODIFIER_D341B'
    kmi.properties.keep_open = True
    addon_keymaps['2E0B0'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.add_22836', 'TWO', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=True)
    addon_keymaps['EA2B7'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('sna.remove_d06a0', 'THREE', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=True)
    addon_keymaps['69F63'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.select_all_mesh_2117b', 'ONE', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    addon_keymaps['62B11'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_isoline_display
    del bpy.types.Scene.sna_single_levels
    del bpy.types.Scene.sna_master_level
    del bpy.types.Scene.sna_show_info
    del bpy.types.Scene.sna_show_options
    bpy.utils.unregister_class(SNA_AddonPreferences_BF64D)
    bpy.utils.unregister_class(SNA_OT_Remove_D06A0)
    bpy.utils.unregister_class(SNA_OT_Add_22836)
    bpy.utils.unregister_class(SNA_OT_Select_All_Mesh_2117B)
    bpy.utils.unregister_class(SNA_OT_More_00F1C)
    bpy.utils.unregister_class(SNA_OT_Less_03742)
    bpy.utils.unregister_class(SNA_PT_QUICK_SUBDIVISON_MODIFIER_D341B)
